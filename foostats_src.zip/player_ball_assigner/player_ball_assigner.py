import sys
from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.append(str(PROJECT_ROOT))
from utils import get_center_of_bbox, measure_distance


class PlayerBallAssigner:
    def __init__(self):
        self.max_player_ball_distance = 70
        self._last_assigned = -1  # estado para histéresis

    def assign_ball_to_player(self, players, ball_bbox):
        ball_position = get_center_of_bbox(ball_bbox)

        minimum_distance = float('inf')
        assigned_player = -1

        for player_id, player in players.items():
            player_bbox = player['bbox']
            distance_left = measure_distance((player_bbox[0], player_bbox[-1]), ball_position)
            distance_right = measure_distance((player_bbox[2], player_bbox[-1]), ball_position)
            distance = min(distance_left, distance_right)

            if distance < self.max_player_ball_distance:
                if distance < minimum_distance:
                    minimum_distance = distance
                    assigned_player = player_id

        # Histéresis: el poseedor actual mantiene la pelota a menos que
        # otro jugador esté al menos un 20% más cerca.
        # Esto elimina el flickering cuando dos jugadores están a distancias similares.
        if self._last_assigned != -1 and self._last_assigned in players:
            last_bbox = players[self._last_assigned]['bbox']
            last_dist = min(
                measure_distance((last_bbox[0], last_bbox[-1]), ball_position),
                measure_distance((last_bbox[2], last_bbox[-1]), ball_position)
            )
            if last_dist < self.max_player_ball_distance:
                # Solo cambiar de poseedor si el nuevo está >20% más cerca
                if assigned_player != self._last_assigned:
                    if minimum_distance > last_dist * 0.80:
                        assigned_player = self._last_assigned

        if assigned_player != -1:
            self._last_assigned = assigned_player

        return assigned_player
