from utils import read_video, save_video, frame_stream, get_video_info
from trackers import Tracker
import supervision as sv
import cv2
import numpy as np
from teams_assigner import TeamAssigner
from player_ball_assigner import PlayerBallAssigner
from camara_movement_estimator import CamaraMovementEstimator
from view_transformer import ViewTransformer
from speed_and_distance_estimator import SpeedAndDistanceEstimator


def main():
    VIDEO_PATH = 'input_videos/08fd33_4.mp4'
    MODEL_PATH = 'models/best.pt'
    OUTPUT_PATH = 'output_videos/output_video.avi'
    BATCH_SIZE = 500
    OVERLAP = 30

    fps, total_frames, frame_width, frame_height = get_video_info(VIDEO_PATH)
    print(f"Video: {total_frames} frames at {fps:.1f} fps ({total_frames/fps/60:.1f} min)")

    # --- One-time setup: calibrate on FIRST FRAME ONLY ---
    # Solo necesitamos 1 frame para calibrar colores de equipo, no 500.
    print("Calibrating team colors on first frame...")
    cap = cv2.VideoCapture(VIDEO_PATH)
    _, first_frame = cap.read()
    cap.release()

    tracker = Tracker(MODEL_PATH)

    # Detectar solo 1 frame para obtener jugadores del primer frame
    first_tracks = tracker.get_object_tracks([first_frame], read_from_stub=False)

    team_assigner = TeamAssigner()
    team_assigner.assign_team_color(first_frame, first_tracks['players'][0])
    tracker.tracker = sv.ByteTrack()    # reset: la calibración no debe contaminar el tracking
    team_assigner.player_team_dict = {} # limpiar IDs del frame de calibración
    print("Team colors calibrated.")

    # --- Initialize output video writer ---
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    writer = cv2.VideoWriter(OUTPUT_PATH, fourcc, fps, (frame_width, frame_height))

    # --- Persistent state across windows ---
    accumulated_distance = {}
    team_ball_control = []          # rolling list, kept in memory (1 int per frame, ~1MB for 90min)
    player_assigner = PlayerBallAssigner()
    camera_movement_estimator = CamaraMovementEstimator(first_frame)
    view_transformer = ViewTransformer()
    speed_and_distance_estimator = SpeedAndDistanceEstimator(frame_rate=fps)

    # --- Process windows ---
    frames_written = 0
    try:
        for batch_idx, (window_frames, start_idx, fps_batch, fw, fh, is_last) in enumerate(
            frame_stream(VIDEO_PATH, batch_size=BATCH_SIZE, overlap=OVERLAP)
        ):
            print(f"Processing batch {batch_idx+1}: frames {start_idx}\u2013{start_idx+len(window_frames)-1}")

            # 1. Detect + track
            window_tracks = tracker.get_object_tracks(window_frames, read_from_stub=False)

            # 2. Add positions
            tracker.add_position_to_tracks(window_tracks)

            # 3. Camera motion
            camera_movement_per_frame = camera_movement_estimator.get_camera_movement(
                window_frames, read_from_stub=False
            )
            camera_movement_estimator.add_adjust_positions_to_tracks(
                window_tracks, camera_movement_per_frame
            )

            # 4. Perspective transform
            view_transformer.add_transformed_position_to_tracks(window_tracks)

            # 5. Ball interpolation
            window_tracks['ball'] = tracker.interpolate_ball_positions(window_tracks['ball'])

            # 6. Speed and distance (with carry-over state)
            accumulated_distance = speed_and_distance_estimator.add_speed_and_distance_to_tracks(
                window_tracks, accumulated_distance
            )

            # 7. Team assignment (uses calibrated kmeans, no refit)
            for frame_num, player_track in enumerate(window_tracks['players']):
                for player_id, track in player_track.items():
                    team = team_assigner.get_player_team(
                        window_frames[frame_num], track['bbox'], player_id
                    )
                    window_tracks['players'][frame_num][player_id]['team'] = team
                    window_tracks['players'][frame_num][player_id]['team_color'] = \
                        team_assigner.team_colors[team]

            # 7b. Goalkeeper team assignment (by field position, not color)
            window_frame_width = window_frames[0].shape[1]
            for frame_num, goalkeeper_track in enumerate(window_tracks['goalkeepers']):
                for gk_id, track in goalkeeper_track.items():
                    team = team_assigner.get_goalkeeper_team(
                        window_frames[frame_num], track['bbox'], window_frame_width
                    )
                    window_tracks['goalkeepers'][frame_num][gk_id]['team'] = team
                    window_tracks['goalkeepers'][frame_num][gk_id]['team_color'] = \
                        team_assigner.team_colors[team]

            # 8. Ball possession
            window_ball_control = []
            for frame_num, player_track in enumerate(window_tracks['players']):
                ball_frame = window_tracks['ball'][frame_num]
                if 1 not in ball_frame:
                    window_ball_control.append(team_ball_control[-1] if team_ball_control else 1)
                    continue
                ball_bbox = ball_frame[1]['bbox']
                assigned_player = player_assigner.assign_ball_to_player(player_track, ball_bbox)
                if assigned_player != -1:
                    window_tracks['players'][frame_num][assigned_player]['has_ball'] = True
                    window_ball_control.append(
                        window_tracks['players'][frame_num][assigned_player]['team']
                    )
                else:
                    window_ball_control.append(team_ball_control[-1] if team_ball_control else 1)

            team_ball_control.extend(window_ball_control)
            team_ball_control_arr = np.array(team_ball_control)

            # 9. Draw annotations
            # Only render the non-overlap zone (all frames if last batch)
            frames_to_render = len(window_frames) if is_last else len(window_frames) - OVERLAP

            annotated_frames = tracker.draw_annotations(
                window_frames[:frames_to_render],
                {k: v[:frames_to_render] for k, v in window_tracks.items()},
                team_ball_control_arr,
                frame_offset=frames_written
            )
            annotated_frames = camera_movement_estimator.draw_camera_movement(
                annotated_frames, camera_movement_per_frame[:frames_to_render]
            )
            annotated_frames = speed_and_distance_estimator.draw_speed_and_distance(
                annotated_frames,
                {k: v[:frames_to_render] for k, v in window_tracks.items()}
            )

            # 10. Write frames to disk immediately, then discard
            for frame in annotated_frames:
                writer.write(frame)
            frames_written += len(annotated_frames)
            print(f"  \u2192 {frames_written} frames written total")

            # Explicitly free window memory
            del window_frames, window_tracks, annotated_frames
    finally:
        writer.release()

    print(f"Done. Output: {OUTPUT_PATH} ({frames_written} frames)")


if __name__ == "__main__":
    main()
